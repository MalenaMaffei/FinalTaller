#ifndef TPFINAL_VISTAPSYCHODISPARAR_H
#define TPFINAL_VISTAPSYCHODISPARAR_H

#include "VistaDireccionada.h"
class VistaPsychoDisparar : public VistaDireccionada {
 public:
  VistaPsychoDisparar(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTAPSYCHODISPARAR_H

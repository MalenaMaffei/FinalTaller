#ifndef TPFINAL_VISTAMUERTETANQUE_H
#define TPFINAL_VISTAMUERTETANQUE_H

#include "Vista.h"
class VistaTanqueMorir : public Vista{
 public:
  VistaTanqueMorir(SDL_Renderer *gRenderer);
//  bool isLastClip(int clip) const;
};

#endif //TPFINAL_VISTAMUERTETANQUE_H

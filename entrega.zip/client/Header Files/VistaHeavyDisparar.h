#ifndef TPFINAL_VISTAHEAVYDISPARAR_H
#define TPFINAL_VISTAHEAVYDISPARAR_H

#include "VistaDireccionada.h"
class VistaHeavyDisparar : public  VistaDireccionada{
 public:
  VistaHeavyDisparar(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTAHEAVYDISPARAR_H

#ifndef TPFINAL_VISTAPYRODISPARAR_H
#define TPFINAL_VISTAPYRODISPARAR_H

#include "VistaDireccionada.h"
class VistaPyroDisparar : public VistaDireccionada {
 public:
  VistaPyroDisparar(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTAPYRODISPARAR_H

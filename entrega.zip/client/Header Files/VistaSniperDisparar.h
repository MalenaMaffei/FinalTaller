#ifndef TPFINAL_VISTASNIPERDISPARAR_H
#define TPFINAL_VISTASNIPERDISPARAR_H

#include "VistaDireccionada.h"
class VistaSniperDisparar: public VistaDireccionada {
 public:
  VistaSniperDisparar(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTASNIPERDISPARAR_H

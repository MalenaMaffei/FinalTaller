#ifndef TPFINAL_VISTABANDERA_H
#define TPFINAL_VISTABANDERA_H

#include "Vista.h"
#include "VistaColoreada.h"
class VistaBandera : public VistaColoreada {
 public:
  VistaBandera(SDL_Renderer *gRenderer);
};

#endif //TPFINAL_VISTABANDERA_H

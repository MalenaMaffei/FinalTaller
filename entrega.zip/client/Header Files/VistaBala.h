#ifndef TPFINAL_VISTABALA_H
#define TPFINAL_VISTABALA_H

#include "Vista.h"
class VistaBala : public Vista {
 public:
  VistaBala(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTABALA_H

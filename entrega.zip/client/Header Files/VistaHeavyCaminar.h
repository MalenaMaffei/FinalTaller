#ifndef TPFINAL_VISTAHEAVY_H
#define TPFINAL_VISTAHEAVY_H

#include "VistaDireccionada.h"
class VistaHeavyCaminar : public VistaDireccionada {
 public:
  VistaHeavyCaminar(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTAHEAVY_H

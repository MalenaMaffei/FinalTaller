#ifndef TPFINAL_VISTAGUI_H
#define TPFINAL_VISTAGUI_H

#include "Vista.h"
class VistaGui : public Vista{
 public:
  VistaGui(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTAGUI_H

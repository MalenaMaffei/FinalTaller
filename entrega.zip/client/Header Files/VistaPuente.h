#ifndef TPFINAL_VISTAPUENTE_H
#define TPFINAL_VISTAPUENTE_H

#include "Vista.h"
class VistaPuente : public Vista {
 public:
  VistaPuente(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTAPUENTE_H

#ifndef TPFINAL_VISTAFUERTE_H
#define TPFINAL_VISTAFUERTE_H

#include "Vista.h"
class VistaFuerte : public Vista {
 public:
  VistaFuerte(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTAFUERTE_H

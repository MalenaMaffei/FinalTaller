#ifndef TPFINAL_VISTAROBOTCAMINAR_H
#define TPFINAL_VISTAROBOTCAMINAR_H

#include "VistaDireccionada.h"
class VistaRobotCaminar : public VistaDireccionada{
 public:
  VistaRobotCaminar(SDL_Renderer *gRenderer);
 public:


};

#endif //TPFINAL_VISTAROBOTCAMINAR_H

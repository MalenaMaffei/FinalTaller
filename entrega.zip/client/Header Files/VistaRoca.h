#ifndef TPFINAL_VISTAROCA_H
#define TPFINAL_VISTAROCA_H
#include "Vista.h"

class VistaRoca : public Vista{
 public:
  VistaRoca(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTAROCA_H

#ifndef TPFINAL_VISTAHUDCARAS_H
#define TPFINAL_VISTAHUDCARAS_H

#include "Vista.h"
class VistaHudCaras  : public Vista {
 public:
  VistaHudCaras(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTAHUDCARAS_H

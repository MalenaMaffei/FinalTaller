#ifndef TPFINAL_VISTAMISSILELAUNCHER_H
#define TPFINAL_VISTAMISSILELAUNCHER_H

#include "VistaDireccionada.h"
class VistaMissilelauncher : public VistaDireccionada {
 public:
  VistaMissilelauncher(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTAMISSILELAUNCHER_H

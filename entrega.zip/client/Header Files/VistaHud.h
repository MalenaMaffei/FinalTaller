#ifndef TPFINAL_VISTAHUD_H
#define TPFINAL_VISTAHUD_H

#include "Vista.h"
class VistaHud  : public Vista{
 public:
  VistaHud(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTAHUD_H

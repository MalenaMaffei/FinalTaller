#ifndef TPFINAL_VISTAMUERTEROBOT_H
#define TPFINAL_VISTAMUERTEROBOT_H

#include "Vista.h"
class VistaRobotMorir : public Vista{
 public:
  VistaRobotMorir(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTAMUERTEROBOT_H

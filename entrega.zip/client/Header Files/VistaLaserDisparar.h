#ifndef TPFINAL_VISTALASERDISPARAR_H
#define TPFINAL_VISTALASERDISPARAR_H

#include "VistaDireccionada.h"
class VistaLaserDisparar : public VistaDireccionada{
 public:
  VistaLaserDisparar(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTALASERDISPARAR_H

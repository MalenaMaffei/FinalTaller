#ifndef TPFINAL_VISTAHUDVEHICULOLABELS_H
#define TPFINAL_VISTAHUDVEHICULOLABELS_H

#include "Vista.h"
class VistaHudVehiculoLabels : public Vista{
 public:
  VistaHudVehiculoLabels(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTAHUDVEHICULOLABELS_H

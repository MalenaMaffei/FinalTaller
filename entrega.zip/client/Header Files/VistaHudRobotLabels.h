#ifndef TPFINAL_VISTAHUDROBOTLABELS_H
#define TPFINAL_VISTAHUDROBOTLABELS_H

#include "Vista.h"
class VistaHudRobotLabels : public Vista{
 public:
  VistaHudRobotLabels(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTAHUDROBOTLABELS_H

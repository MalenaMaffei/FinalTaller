#ifndef TPFINAL_VISTAFABRICAROBOT_H
#define TPFINAL_VISTAFABRICAROBOT_H

#include "Vista.h"
class VistaFabricaRobot : public Vista {
 public:
  VistaFabricaRobot(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTAFABRICAROBOT_H

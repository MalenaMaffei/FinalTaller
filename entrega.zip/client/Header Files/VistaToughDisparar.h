#ifndef TPFINAL_VISTATOUGHDISPARAR_H
#define TPFINAL_VISTATOUGHDISPARAR_H

#include "VistaDireccionada.h"
class VistaToughDisparar : public VistaDireccionada {
 public:
  VistaToughDisparar(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTATOUGHDISPARAR_H

#ifndef TPFINAL_VISTAFABRICAVEHICULO_H
#define TPFINAL_VISTAFABRICAVEHICULO_H

#include "Vista.h"

class VistaFabricaVehiculo : public Vista {
 public:
  VistaFabricaVehiculo(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTAFABRICAVEHICULO_H

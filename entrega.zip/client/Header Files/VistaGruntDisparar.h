#ifndef TPFINAL_VISTAGRUNTDISPARAR_H
#define TPFINAL_VISTAGRUNTDISPARAR_H

#include "VistaDireccionada.h"
class VistaGruntDisparar: public VistaDireccionada {
 public:
  VistaGruntDisparar(SDL_Renderer *gRenderer);

};

#endif //TPFINAL_VISTAGRUNTDISPARAR_H

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   server_constants.h
 * Author: usuario
 *
 * Created on 3 de junio de 2017, 11:49
 */

#ifndef SERVER_CONSTANTS_H
#define SERVER_CONSTANTS_H

#define TICKS 30    //per second
#define CYCLE_TIME (1.0/TICKS) //in seconds
#define NANO 1000000000ULL


#endif /* SERVER_CONSTANTS_H */

